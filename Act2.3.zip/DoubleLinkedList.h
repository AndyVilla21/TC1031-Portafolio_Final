//
// Created by dario on 07/10/2020.
//

#ifndef UNTITLED8_DOUBLELINKEDLIST_H
#define UNTITLED8_DOUBLELINKEDLIST_H
#include "Node.h"
#include <iostream>
using namespace std;


class DoubleLinkedList{
public:
    DoubleLinkedList();
    ~DoubleLinkedList();
    void addFirst(info data);
    void addLast(info data);
    int deleteAll();
    int getSize();
    void swap(Node *node1, Node *node2);
    void sort();
    void search(long data, long data2);
private:
    Node *head, *tail;
    int size;
};


DoubleLinkedList::DoubleLinkedList(){
    head = nullptr;
    tail = nullptr;
    size = 0;
}


DoubleLinkedList::~DoubleLinkedList(){
    deleteAll();
}

//Complejidad: O(1)
// Agrega un elemento al principio de la estructura de datos

void DoubleLinkedList::addFirst(info data){
    if (head != nullptr){
        head = new Node(data,head, nullptr);
        Node *temp = head ->getNext();
        temp ->setPrev(head);
    }
    else
    {
        head = new Node(data,head, nullptr);
        tail = head;
    }
    size++;
}

//Complejidad: O(n)
// Agrega un elemento al final de la estructura de datos

void DoubleLinkedList::addLast(info data){

    if (size == 0)
        addFirst(data);
    else
    {
        tail = new Node(data, nullptr, tail);
        Node *temp = tail -> getPrev();
        temp -> setNext(tail);
    }
    size++;
}

// Complejidad: O(n)
// Elimina todos los elementos de la estructura de datos

int DoubleLinkedList::deleteAll(){
    Node *curr = head;
    while (head != nullptr){
        head = head->getNext();			// Avanza 1 a head;
        delete curr;					// Elimina curr
        curr = head;					// Curr lo alinea con head;
    }
    int sizeAux = size;
    size = 0;
    return sizeAux;
}

//Complejidad: O(1)
// Retorna el size de la estructura de datos

int DoubleLinkedList::getSize(){
    return size;
}

// Complejidad O(n)
// Busca entre el rango dado de Ips las Ips encontradas en la linked list las cuales imprime y con las cuales se crea un archivo nuevo

void DoubleLinkedList::search(long data1, long data2) {
  ofstream Archivo("registros.txt",std::ios::app);
   Node *curr = head;
   bool found = false;
   cout << "\n\n -------------------------------- FOUND IPS --------------------------------\n\n";

   Archivo << "\n\n -------------------------------- FOUND IPS --------------------------------\n\n";
   while(curr != nullptr) {
      if(curr->getData().key >= data1 && curr->getData().key <= data2) {
        cout << curr -> getData().iP << endl << endl;;
        Archivo << curr -> getData().iP << endl;
        found = true;
      } 
      curr = curr->getNext();
   }
         if (found != true){
         cout << "No hay registros disponibles - Ingrese una iP valida" << endl;
      }
      cout << "\n\n ---------------------------------------------------------------------------\n";
      Archivo << "\n\n ----------------------------------------------------------------------------\n";
   Archivo.close();
}

// Complejidad O(1)
// Intercambia los datos entre 2 nodos

void DoubleLinkedList::swap(Node *node1, Node *node2) {
    info curr = node1 ->getData();
    node1 ->setData(node2->getData());
    node2 ->setData(curr);
}

//Complejidad O(n^2)
// Arregla la linked list con base a los valores de Ips

void DoubleLinkedList::sort() {
    int swapped;
    Node *curr;
    Node *aux = nullptr;
    do {
        swapped = 0;
        curr = head;
        while (curr ->getNext() != aux){
            if (curr->getData().iP > curr->getNext()->getData().iP){
                swap(curr,curr->getNext());
                swapped = 1;
            }
            curr = curr ->getNext();
        }
        aux = curr;
    }
    while (swapped);
}

#endif //UNTITLED8_DOUBLELINKEDLIST_H
