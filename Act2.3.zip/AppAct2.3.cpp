/*

6/10/2020

Dario Jauregui A00827837
José Andrés Villarreal A00829355

Actividad 2.3
*/

#include <iostream>
#include <vector>
#include <fstream>
#include "Node.h"
#include "DoubleLinkedList.h"

using namespace std;

// Complejidad O(n)
long ipToLong(string ip){
	int idx = 0;
	long datoFinal= 0, dato = 0;
	while (idx < ip.size()){
		if (ip[idx]!= '.' && ip[idx]!=':'){
			dato = dato*10 + ip[idx]-'0';
		}
		else{
			datoFinal = datoFinal*1000 + dato;
			dato = 0;
		}
		idx++;
	}
	datoFinal = datoFinal*10000 + dato;
	return datoFinal;
}

// Complejidad O(n)
// Lee información del archivo .txt y lo almacena en un vector de struct
void readData(DoubleLinkedList list){
    long day, key, count = 0, ip, ip2;
    string month,hour,iP,message,id,id2;
    info data;
    ifstream file;
    file.open("bitacora.txt");

    while(file >> month >> day >> hour >> iP){
        getline(file,message);
        data.month = month;
        data.day = day;
        data.hour = hour;
        data.iP = iP;

        // Se crea una "key" que sirve para pasar la iP de string a long

        data.key = ipToLong(iP);
        data.message = message;
        list.addLast(data);
    }

    file.close();
    list.sort();
    cout << "Ingresa el valor de inicio de Ip para la busqueda de iPs" << endl;
    cin >> id;
    cout << "Ingresa el valor de Ip final para la busqueda de iPs" << endl;
    cin >> id2;
    ip = ipToLong(id);
    ip2 = ipToLong(id2);
    list.search(ip,ip2);
}

int main() {
    int inicio, final, n = 0;
    DoubleLinkedList list;
    readData(list);
    return 0;
}
