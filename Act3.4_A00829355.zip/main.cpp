/*

24/10/2020

Dario Jauregui A00827837
José Andrés Villarreal A00829355

Actividad 3.4
*/

#include <iostream>
#include <vector>
#include <fstream>
#include "BST.h"
#include "Node.h"
#include <sstream>
#include <string>

using namespace std;

// Complejidad O(n)
long ipToLong(string ip){
	int idx = 0;
	long datoFinal= 0, dato = 0;
	while (idx < ip.size()){
		if (ip[idx]!= '.'){
			dato = dato*10 + ip[idx]-'0';
		}
		else{
			datoFinal = datoFinal*1000 + dato;
			dato = 0;
		}
		idx++;
	}
	datoFinal = datoFinal*10000 + dato;
	return datoFinal;
}

long split(string ip){
string IPNueva= ip.substr(0, ip.find(":"));

return ipToLong(IPNueva);

}


// Complejidad O(n)
// Lee información del archivo .txt y lo almacena en un vector de struct
void readData(BST list){
    long day, key, count = 0, ip, ip2;
    string month,hour,iP,message,id,id2;
    info data;
    ifstream file;
    data.iPant = 0;
    long contAcc = 0;
    
    file.open("bitacoraOrdenada.txt");

    while(file >> month >> day >> hour >> iP){
        getline(file,message);
        data.month = month;
        data.day = day;
        data.hour = hour;
        data.iP = iP; 
        data.iPnueva = split(iP); 
        if (data.iPnueva != data.iPant && contAcc > 0){
          list.add(data);
          data.iPant = data.iPnueva;
          contAcc = 1;
        }
        else{
          data.iPant = data.iPnueva;
          contAcc++;
        }
        data.key = contAcc;
    }
    file.close();
    list.visit();
}


int main() {
    int inicio, final, n = 0;
    BST list;
    readData(list);
    return 0;
}
