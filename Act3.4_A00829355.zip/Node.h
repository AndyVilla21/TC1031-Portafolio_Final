//
// Created by dario on 07/10/2020.
//

#ifndef UNTITLED8_NODE_H
#define UNTITLED8_NODE_H
#include <iostream>
using namespace std;

struct info{
    long key;
    string month;
    long day;
    string hour;
    string message;
    string iP;
    long iPnueva;
    long iPant;
    long cont;
};

class Node{
public:
    Node(info data);
    Node(info data, Node *left, Node *right);
    info getData();
    Node* getLeft();
    Node* getRight();
    void setData(info data);
    void setLeft(Node *left);
    void setRight(Node *right);
private:
    info data;
    Node *left;
    Node *right;
};


Node::Node(info data){
    this->data = data;
    this->left = nullptr;
    this->right = nullptr;
}


Node::Node(info data, Node* left, Node *right){
    this->data = data;
    this->left = left;
    this->right = right;
}

info Node::getData(){
    return data;
}

Node* Node::getLeft(){
    return left;
}

Node* Node::getRight(){
    return right;
}

void Node::setData(info data){
    this->data = data;
}

void Node::setLeft(Node *left){
    this->left = left;
}

void Node::setRight(Node *right){
    this->right = right;
}

#endif //UNTITLED8_NODE_H